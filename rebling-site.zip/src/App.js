// App.js
// 여기에 완성된 React + Firebase 코드가 들어갈 예정입니다.
console.log("REBLING App 로딩됨");
